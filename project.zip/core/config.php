<?php
    $servername = "localhost";
    $username = "pma";
    $password = "1234";
    $dbname = "users";
?>