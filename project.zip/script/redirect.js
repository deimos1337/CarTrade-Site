if (userEmail == ''){
    location.href = "login.html";
    alert('Для доступа в данный раздел, необходимо авторизоваться!');
} else {
    console.log('Всё норм)');
}