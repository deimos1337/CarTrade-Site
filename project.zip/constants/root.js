const ROOT_PRODUCTS = document.getElementById('products');
const ROOT_HEADER = document.getElementById('header');
const ROOT_SHOPPING = document.getElementById('shopping');
const ROOT_FAVORITE = document.getElementById('favorite');
const ROOT_ADMIN = document.getElementById('admin');
const ROOT_COMMENTS = document.getElementById('comments');







